import RegLogin from './RegLogin.vue'
export default RegLogin