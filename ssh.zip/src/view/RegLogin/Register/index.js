import Register from './Register.vue'
export default Register