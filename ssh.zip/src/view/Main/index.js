import Main from './Main.vue'
export default Main
