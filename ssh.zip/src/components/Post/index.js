import Post from './Post.vue'
export default Post
