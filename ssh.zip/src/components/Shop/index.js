import Shop from './Shop.vue'
export default Shop
