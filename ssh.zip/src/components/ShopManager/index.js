import ShopManager from "./ShopManager.vue";
export default ShopManager;