import User from './User.vue'
export default User
